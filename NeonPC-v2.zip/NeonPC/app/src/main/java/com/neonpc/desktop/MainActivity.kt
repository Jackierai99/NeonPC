package com.neonpc.desktop

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.InputDevice
import android.view.MotionEvent
import android.view.ViewConfiguration
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlin.math.abs
import kotlin.math.hypot

class MainActivity : ComponentActivity() {
    private val h = Handler(Looper.getMainLooper())

    // ---- virtual mouse (touchpad) state ----
    private var passthrough = true       // this gesture goes straight to the UI (touch mode / corner / panel)
    private var slop = 8f
    private var lastX = 0f
    private var lastY = 0f
    private var downX = 0f
    private var downY = 0f
    private var downT = 0L
    private var moved = false
    private var dragging = false         // virtual left button is held
    private var lastTapUp = 0L
    private var scrolling = false        // two-finger scroll
    private var scrollStarted = false
    private var scrollX = 0f
    private var scrollY = 0f
    private var midX = 0f
    private var midY = 0f
    private var twoMoved = 0f
    private var twoDownT = 0L
    private var ignoreRest = false
    private var synthDown = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.load(this)
        slop = ViewConfiguration.get(this).scaledTouchSlop.toFloat()
        val dm = resources.displayMetrics
        Mouse.x = dm.widthPixels / 2f
        Mouse.y = dm.heightPixels / 2f
        WindowCompat.setDecorFitsSystemWindows(window, false)
        hideBars()
        setContent { Desktop() }
    }

    private fun hideBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.hide(WindowInsetsCompat.Type.systemBars())
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    // ================= Winlator-style mouse =================
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            val corner = 84f * resources.displayMetrics.density   // the 3-dots button always works by direct touch
            passthrough = !Cfg.mouse || Cfg.panel || (ev.x < corner && ev.y < corner)
        }
        if (passthrough) return super.dispatchTouchEvent(ev)
        mouseEvent(ev)
        return true
    }

    private fun maxX() = (window.decorView.width.takeIf { it > 0 } ?: resources.displayMetrics.widthPixels) - 1f
    private fun maxY() = (window.decorView.height.takeIf { it > 0 } ?: resources.displayMetrics.heightPixels) - 1f

    /** Sends a synthetic finger event to the UI at (x, y). */
    private fun inject(action: Int, x: Float, y: Float, t: Long = SystemClock.uptimeMillis()) {
        if (action == MotionEvent.ACTION_DOWN) synthDown = t
        val e = MotionEvent.obtain(synthDown, t, action, x, y, 0)
        e.source = InputDevice.SOURCE_TOUCHSCREEN
        window.superDispatchTouchEvent(e)
        e.recycle()
    }

    private fun click() {
        val t = SystemClock.uptimeMillis()
        inject(MotionEvent.ACTION_DOWN, Mouse.x, Mouse.y, t)
        inject(MotionEvent.ACTION_UP, Mouse.x, Mouse.y, t + 30)
    }

    /** Right click = long press at the arrow. */
    private fun rightClick() {
        inject(MotionEvent.ACTION_DOWN, Mouse.x, Mouse.y)
        h.postDelayed({ inject(MotionEvent.ACTION_UP, Mouse.x, Mouse.y) }, 650)
    }

    private fun endScroll(t: Long) {
        if (scrollStarted) inject(MotionEvent.ACTION_UP, scrollX, scrollY)
        else if (t - twoDownT < 350 && twoMoved <= slop) rightClick()
        scrolling = false
        scrollStarted = false
        ignoreRest = true
    }

    private fun mouseEvent(ev: MotionEvent) {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = ev.x; lastY = ev.y; downX = ev.x; downY = ev.y; downT = ev.eventTime
                moved = false; scrolling = false; scrollStarted = false; ignoreRest = false
                if (ev.eventTime - lastTapUp < 280) {          // tap, then touch again = hold left button (drag)
                    inject(MotionEvent.ACTION_DOWN, Mouse.x, Mouse.y)
                    dragging = true
                }
            }

            MotionEvent.ACTION_POINTER_DOWN -> {
                if (!dragging && !scrolling && !ignoreRest && ev.pointerCount == 2) {
                    scrolling = true
                    scrollStarted = false
                    twoMoved = 0f
                    twoDownT = ev.eventTime
                    midX = (ev.getX(0) + ev.getX(1)) / 2f
                    midY = (ev.getY(0) + ev.getY(1)) / 2f
                    scrollX = Mouse.x
                    scrollY = Mouse.y
                }
            }

            MotionEvent.ACTION_MOVE -> {
                if (ignoreRest) return
                if (scrolling) {
                    if (ev.pointerCount < 2) return
                    val mx = (ev.getX(0) + ev.getX(1)) / 2f
                    val my = (ev.getY(0) + ev.getY(1)) / 2f
                    val dx = mx - midX
                    val dy = my - midY
                    midX = mx; midY = my
                    twoMoved += abs(dx) + abs(dy)
                    if (!scrollStarted && twoMoved > slop) {
                        scrollStarted = true
                        inject(MotionEvent.ACTION_DOWN, scrollX, scrollY)
                    }
                    if (scrollStarted) {
                        scrollX += dx
                        scrollY += dy
                        if (scrollX < 20f || scrollY < 20f || scrollX > maxX() - 20f || scrollY > maxY() - 20f) {
                            // reached the screen edge: restart the scroll from the arrow
                            inject(MotionEvent.ACTION_CANCEL, scrollX.coerceIn(0f, maxX()), scrollY.coerceIn(0f, maxY()))
                            scrollX = Mouse.x; scrollY = Mouse.y
                            inject(MotionEvent.ACTION_DOWN, scrollX, scrollY)
                        } else inject(MotionEvent.ACTION_MOVE, scrollX, scrollY)
                    }
                    return
                }
                val dx = ev.x - lastX
                val dy = ev.y - lastY
                lastX = ev.x; lastY = ev.y
                if (!moved && hypot(ev.x - downX, ev.y - downY) > slop) moved = true
                Mouse.x = (Mouse.x + dx * Cfg.speed).coerceIn(0f, maxX())
                Mouse.y = (Mouse.y + dy * Cfg.speed).coerceIn(0f, maxY())
                if (dragging) inject(MotionEvent.ACTION_MOVE, Mouse.x, Mouse.y)
            }

            MotionEvent.ACTION_POINTER_UP -> {
                if (scrolling) endScroll(ev.eventTime)
            }

            MotionEvent.ACTION_UP -> {
                if (scrolling) endScroll(ev.eventTime)
                if (ignoreRest) { ignoreRest = false; return }
                if (dragging) {
                    inject(MotionEvent.ACTION_UP, Mouse.x, Mouse.y)
                    dragging = false
                    lastTapUp = 0L
                } else if (!moved && ev.eventTime - downT < 300) {
                    click()
                    lastTapUp = ev.eventTime
                } else lastTapUp = 0L
            }

            MotionEvent.ACTION_CANCEL -> {
                if (dragging) inject(MotionEvent.ACTION_UP, Mouse.x, Mouse.y)
                if (scrollStarted) inject(MotionEvent.ACTION_CANCEL, scrollX, scrollY)
                dragging = false; scrolling = false; scrollStarted = false; ignoreRest = false; lastTapUp = 0L
            }
        }
    }
}
