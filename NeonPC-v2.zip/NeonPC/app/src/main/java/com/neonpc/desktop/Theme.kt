package com.neonpc.desktop

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import kotlin.random.Random

// ================= app catalogue (icons are drawn by us: coloured tile + symbol) =================
class AppDef(val kind: String, val name: String, val emoji: String, val c1: Color, val c2: Color)

val APPS = listOf(
    AppDef("web", "Browser", "🌐", Color(0xFF2EA8FF), Color(0xFF0A5BD8)),
    AppDef("files", "File Explorer", "📁", Color(0xFFFFD04D), Color(0xFFF2A100)),
    AppDef("notes", "Notepad", "📝", Color(0xFF6CC4FF), Color(0xFF2B7CD3)),
    AppDef("calc", "Calculator", "🧮", Color(0xFF5B6270), Color(0xFF2E333D)),
    AppDef("paint", "Paint", "🎨", Color(0xFFFF8A65), Color(0xFFD84A8C)),
    AppDef("term", "Terminal", "⌨", Color(0xFF3A3A3A), Color(0xFF111111)),
    AppDef("tasks", "Task Manager", "📊", Color(0xFF3DDC97), Color(0xFF0E9F6E)),
    AppDef("exe", "Windows Apps", "📦", Color(0xFF8E7CFF), Color(0xFF5A3FD6))
)
val SETTINGS_APP = AppDef("settings", "Settings", "⚙", Color(0xFF8A8F98), Color(0xFF4B5058))
val PC_APP = AppDef("pc", "This PC", "💻", Color(0xFF5CC8FF), Color(0xFF1C7ED6))
val BIN_APP = AppDef("bin", "Recycle Bin", "🗑", Color(0xFF9AA7B4), Color(0xFF5C6B7A))

fun appOf(kind: String): AppDef = APPS.firstOrNull { it.kind == kind } ?: APPS[0]

@Composable
fun AppIcon(a: AppDef, size: Dp) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(size * 0.24f)).background(Brush.linearGradient(listOf(a.c1, a.c2))),
        contentAlignment = Alignment.Center
    ) { Text(a.emoji, fontSize = (size.value * 0.55f).sp) }
}

// ================= wallpapers =================
val WALLS = listOf("Bloom", "Night", "Aurora", "Sunset", "Neon Grid", "Dark")

fun DrawScope.drawWall(idx: Int, low: Boolean) {
    val w = size.width
    val h = size.height
    when (idx) {
        1 -> { // Night
            drawRect(Brush.linearGradient(listOf(Color(0xFF05061A), Color(0xFF1B1550), Color(0xFF3A1C71)), Offset(0f, 0f), Offset(w, h)))
            if (!low) {
                val rnd = Random(7)
                repeat(70) {
                    drawCircle(Color.White.copy(alpha = 0.3f + 0.7f * rnd.nextFloat()), 1f + 2f * rnd.nextFloat(), Offset(rnd.nextFloat() * w, rnd.nextFloat() * h * 0.85f))
                }
            }
        }
        2 -> { // Aurora
            drawRect(Brush.linearGradient(listOf(Color(0xFF031A1A), Color(0xFF06604F), Color(0xFF3DDC97)), Offset(0f, h), Offset(w, 0f)))
            if (!low) {
                drawOval(Brush.radialGradient(listOf(Color(0x66A8FFE0), Color(0x0006604F)), Offset(w * 0.35f, h * 0.4f), w * 0.4f), Offset(w * 0.0f, h * 0.15f), Size(w * 0.7f, h * 0.5f))
                drawOval(Brush.radialGradient(listOf(Color(0x5580D8FF), Color(0x00063A60)), Offset(w * 0.7f, h * 0.55f), w * 0.4f), Offset(w * 0.35f, h * 0.3f), Size(w * 0.65f, h * 0.55f))
            }
        }
        3 -> { // Sunset
            drawRect(Brush.verticalGradient(listOf(Color(0xFF2B0B3F), Color(0xFFD6457A), Color(0xFFFFB86B))))
            if (!low) drawCircle(Brush.radialGradient(listOf(Color(0xFFFFF1C2), Color(0x00FFB86B)), Offset(w * 0.5f, h * 0.72f), h * 0.35f), h * 0.35f, Offset(w * 0.5f, h * 0.72f))
        }
        4 -> { // Neon grid
            drawRect(Brush.linearGradient(listOf(Color(0xFF05010F), Color(0xFF1A0540), Color(0xFF00202A))))
            if (!low) {
                for (i in 0..24) drawLine(NEON.copy(alpha = 0.07f), Offset(i * w / 24f, 0f), Offset(i * w / 24f, h), 1.5f)
                for (i in 0..14) drawLine(NEON.copy(alpha = 0.07f), Offset(0f, i * h / 14f), Offset(w, i * h / 14f), 1.5f)
            }
        }
        5 -> drawRect(Color(0xFF101114)) // Dark
        else -> { // 0 = Bloom (blue flower, default)
            drawRect(Brush.linearGradient(listOf(Color(0xFF021B52), Color(0xFF0A47B8), Color(0xFF5FB0FF)), Offset(0f, h), Offset(w, 0f)))
            if (!low) {
                val c = Offset(w * 0.5f, h * 0.5f)
                val r = minOf(w, h) * 0.5f
                for (i in 0 until 6) {
                    rotate(i * 60f + 10f, c) {
                        drawOval(
                            Brush.radialGradient(listOf(Color(0xCCBFE0FF), Color(0x001A5FE0)), Offset(c.x + r * 0.5f, c.y), r * 0.5f),
                            Offset(c.x, c.y - r * 0.26f), Size(r, r * 0.52f)
                        )
                    }
                }
                drawCircle(Brush.radialGradient(listOf(Color(0x99FFFFFF), Color(0x00FFFFFF)), c, r * 0.22f), r * 0.22f, c)
            }
        }
    }
}

/** Saves a gallery photo as the wallpaper (scaled down so it stays light). */
fun saveWall(ctx: Context, uri: Uri): Boolean {
    try {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (o.outWidth / s > 1800 || o.outHeight / s > 1800) s *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = s
        val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return false
        File(ctx.filesDir, "wall.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        return true
    } catch (e: Exception) {
        return false
    }
}

@Composable
fun Wallpaper() {
    val ctx = LocalContext.current
    val custom = if (Cfg.wall == -1) remember(Cfg.wallVer) {
        try { BitmapFactory.decodeFile(File(ctx.filesDir, "wall.jpg").absolutePath)?.asImageBitmap() } catch (e: Exception) { null }
    } else null
    if (custom != null) {
        Image(custom, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    } else {
        Canvas(Modifier.fillMaxSize()) { drawWall(if (Cfg.wall < 0) 0 else Cfg.wall, Cfg.low) }
    }
}

@Composable
fun WallThumb(idx: Int, selected: Boolean, onClick: () -> Unit) {
    val sh = RoundedCornerShape(8.dp)
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(
            Modifier.size(88.dp, 54.dp).clip(sh).border(if (selected) 3.dp else 1.dp, if (selected) NEON else Color(0x55FFFFFF), sh).clickable(onClick = onClick)
        ) { drawWall(idx, false) }
        Text(WALLS[idx], color = if (selected) NEON else Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 3.dp))
    }
}
