package com.neonpc.desktop

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.media.AudioManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/** All user settings. Saved automatically (see Desktop). */
object Cfg {
    var low by mutableStateOf(false)          // low device mode
    var mouse by mutableStateOf(false)        // false = touch, true = mouse (touchpad) mode
    var speed by mutableFloatStateOf(1.8f)    // mouse speed
    var cursor by mutableFloatStateOf(1f)     // mouse arrow size
    var ui by mutableFloatStateOf(1f)         // UI size (zoom)
    var noImg by mutableStateOf(false)        // browser: block images (fast)
    var panel by mutableStateOf(false)        // settings panel open?
    var wall by mutableIntStateOf(0)          // wallpaper index (-1 = photo from gallery)
    var wallVer by mutableIntStateOf(0)       // bumps when the gallery photo changes

    fun load(c: Context) {
        val sp = c.getSharedPreferences("neonpc_cfg", Context.MODE_PRIVATE)
        low = sp.getBoolean("low", false)
        mouse = sp.getBoolean("mouse", false)
        speed = sp.getFloat("speed", 1.8f)
        cursor = sp.getFloat("cursor", 1f)
        ui = sp.getFloat("ui", 1f)
        noImg = sp.getBoolean("noImg", false)
        wall = sp.getInt("wall", 0)
    }

    fun save(c: Context) {
        c.getSharedPreferences("neonpc_cfg", Context.MODE_PRIVATE).edit()
            .putBoolean("low", low).putBoolean("mouse", mouse)
            .putFloat("speed", speed).putFloat("cursor", cursor).putFloat("ui", ui)
            .putBoolean("noImg", noImg).putInt("wall", wall).apply()
    }
}

/** Position of the virtual mouse arrow (pixels). */
object Mouse {
    var x by mutableFloatStateOf(400f)
    var y by mutableFloatStateOf(300f)
}

fun Context.activity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

fun startSys(ctx: Context, action: String) {
    try {
        ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Ye setting khul nahi paayi", Toast.LENGTH_SHORT).show()
    }
}

// ================= the mouse arrow =================
@Composable
fun CursorOverlay() {
    if (!Cfg.mouse || Cfg.panel) return
    val sz = 26.dp * Cfg.cursor
    Canvas(Modifier.offset { IntOffset(Mouse.x.roundToInt(), Mouse.y.roundToInt()) }.size(sz)) {
        val s = size.width / 20f
        val p = Path().apply {
            moveTo(0f, 0f)
            lineTo(0f, 16f * s)
            lineTo(4f * s, 12.5f * s)
            lineTo(7f * s, 19f * s)
            lineTo(10f * s, 17.8f * s)
            lineTo(7.2f * s, 11.4f * s)
            lineTo(12.5f * s, 11.4f * s)
            close()
        }
        drawPath(p, Color.White)
        drawPath(p, Color.Black, style = Stroke(width = 1.5f * s))
    }
}

// ================= settings panel (opens from the 3 dots, top-left) =================
@Composable
fun SettingsPanel(modifier: Modifier, onTaskMgr: () -> Unit, onShowDesktop: () -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val sh = RoundedCornerShape(topEnd = 14.dp, bottomEnd = 14.dp)
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = remember { am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var vol by remember { mutableFloatStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()) }
    var bright by remember { mutableFloatStateOf(0.8f) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            if (saveWall(ctx, uri)) { Cfg.wall = -1; Cfg.wallVer++ }
            else Toast.makeText(ctx, "Photo wallpaper nahi ban paayi", Toast.LENGTH_SHORT).show()
        }
    }

    Column(
        modifier.width(330.dp).clip(sh).background(Color(0xF5101020)).border(1.dp, NEON, sh)
            .verticalScroll(rememberScrollState()).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("⚙  NEON PC Settings", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Box(Modifier.size(40.dp).clickable(onClick = onClose), contentAlignment = Alignment.Center) {
                Text("✕", color = Color(0xFFFF4D6D), fontSize = 18.sp)
            }
        }

        PanelLabel("PERSONALIZATION  (wallpaper)")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            WALLS.indices.forEach { i -> WallThumb(i, Cfg.wall == i) { Cfg.wall = i } }
        }
        Pill("\uD83D\uDDBC  Gallery se photo wallpaper") { pick.launch("image/*") }

        PanelLabel("INPUT  (touch / mouse)")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ModeBtn("👆 Touch", !Cfg.mouse, Modifier.weight(1f)) { Cfg.mouse = false }
            ModeBtn("🖱 Mouse", Cfg.mouse, Modifier.weight(1f)) {
                Cfg.mouse = true
                Toast.makeText(ctx, "Mouse mode ON: screen pe kahin bhi ungli chalao, arrow move hoga.", Toast.LENGTH_LONG).show()
            }
        }
        Text(
            "Mouse mode me: 1 ungli drag = arrow move • 1 tap = click • double-tap + drag = drag/drop • " +
                "2 ungli tap = right-click (long press) • 2 ungli drag = scroll.\nIs ⋮ button par hamesha seedha touch chalta hai.",
            color = Color(0xAAFFFFFF), fontSize = 11.sp
        )
        SliderRow("Mouse speed", Cfg.speed, 0.6f..4f, "%.1fx".format(Cfg.speed)) { Cfg.speed = it }
        SliderRow("Arrow size", Cfg.cursor, 0.6f..2.2f, "%.1fx".format(Cfg.cursor)) { Cfg.cursor = it }

        PanelLabel("PERFORMANCE")
        SwitchRow(
            "Low device mode",
            "Simple wallpaper, kam effects, max 3 windows, kam battery/RAM. Kamzor phone ke liye ON karo.",
            Cfg.low
        ) { Cfg.low = it }
        SwitchRow("Browser: images band", "Pages bahut tez khulte hain, data bhi bachta hai.", Cfg.noImg) { Cfg.noImg = it }

        PanelLabel("DISPLAY & SOUND")
        SliderRow("UI size (zoom)", Cfg.ui, 0.7f..1.4f, "${(Cfg.ui * 100).roundToInt()}%") { Cfg.ui = it }
        SliderRow("Brightness", bright, 0.05f..1f, "${(bright * 100).roundToInt()}%") {
            bright = it
            ctx.activity()?.let { a ->
                val lp = a.window.attributes
                lp.screenBrightness = it
                a.window.attributes = lp
            }
        }
        SliderRow("Volume", vol, 0f..maxVol.toFloat(), "${vol.roundToInt()}/$maxVol") {
            vol = it
            try { am.setStreamVolume(AudioManager.STREAM_MUSIC, it.roundToInt(), 0) } catch (_: Exception) {}
        }

        PanelLabel("SYSTEM")
        Pill("📊  Task Manager") { onClose(); onTaskMgr() }
        Pill("🖥  Show desktop") { onClose(); onShowDesktop() }
        Pill("📶  Wi-Fi") { startSys(ctx, Settings.ACTION_WIFI_SETTINGS) }
        Pill("🔵  Bluetooth") { startSys(ctx, Settings.ACTION_BLUETOOTH_SETTINGS) }
        Pill("🔓  Allow file access") { grantFiles(ctx) }
        Pill("⚙  Android settings") { startSys(ctx, Settings.ACTION_SETTINGS) }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun PanelLabel(t: String) {
    Text(t, color = NEON, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
}

@Composable
fun ModeBtn(t: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val sh = RoundedCornerShape(10.dp)
    Box(
        modifier.clip(sh).background(if (selected) NEON else Color(0x22FFFFFF)).border(1.dp, NEON, sh)
            .clickable(onClick = onClick).padding(vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(t, color = if (selected) Color.Black else Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

@Composable
fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, shown: String, onChange: (Float) -> Unit) {
    Column {
        Row {
            Text(label, color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text(shown, color = NEON, fontSize = 13.sp)
        }
        Slider(
            value = value, onValueChange = onChange, valueRange = range,
            colors = SliderDefaults.colors(thumbColor = NEON, activeTrackColor = NEON, inactiveTrackColor = Color(0x33FFFFFF))
        )
    }
}

@Composable
fun SwitchRow(label: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(desc, color = Color(0xAAFFFFFF), fontSize = 11.sp)
        }
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = NEON)
        )
    }
}
