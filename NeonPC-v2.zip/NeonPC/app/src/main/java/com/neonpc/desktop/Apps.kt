package com.neonpc.desktop

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.text.format.Formatter
import android.view.ViewGroup
import android.webkit.*
import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import java.io.File
import kotlin.math.abs

const val DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

@Composable
fun Pill(text: String, onClick: () -> Unit) {
    val sh = RoundedCornerShape(50)
    Box(Modifier.clip(sh).background(Color(0x22FFFFFF)).border(1.dp, NEON, sh).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 8.dp)) {
        Text(text, color = Color.White, fontSize = 12.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
    }
}

// ================= Browser (Android WebView = Chromium engine, desktop mode) =================
fun fixUrl(s: String): String {
    val t = s.trim()
    return when {
        t.startsWith("http://") || t.startsWith("https://") -> t
        t.contains(" ") || !t.contains(".") -> "https://www.google.com/search?q=" + Uri.encode(t)
        else -> "https://$t"
    }
}

@SuppressLint("SetJavaScriptEnabled")
fun makeWeb(c: Context, win: Win): WebView = WebView(c).apply {
    settings.javaScriptEnabled = true
    settings.domStorageEnabled = true
    settings.userAgentString = DESKTOP_UA
    settings.useWideViewPort = true
    settings.loadWithOverviewMode = true
    settings.setSupportZoom(true)
    settings.builtInZoomControls = true
    settings.displayZoomControls = false
    settings.mediaPlaybackRequiresUserGesture = Cfg.low
    settings.blockNetworkImage = Cfg.noImg
    if (Cfg.low) settings.setSupportMultipleWindows(false)
    CookieManager.getInstance().setAcceptCookie(true)
    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
    webViewClient = object : WebViewClient() {
        override fun onPageFinished(view: WebView?, url: String?) {
            if (url != null) win.url = url
            win.title = (view?.title ?: "Browser").take(24)
        }
    }
    webChromeClient = WebChromeClient()
    // downloads go to the Downloads folder (visible in Files)
    setDownloadListener { url, ua, cd, mime, _ ->
        try {
            val fn = URLUtil.guessFileName(url, cd, mime)
            val r = DownloadManager.Request(Uri.parse(url))
                .setMimeType(mime)
                .addRequestHeader("User-Agent", ua)
                .addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url) ?: "")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fn)
            (c.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(r)
            Toast.makeText(c, "Download shuru: $fn", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(c, "Download fail: " + e.message, Toast.LENGTH_LONG).show()
        }
    }
    loadUrl(win.url)
}

@Composable
fun BrowserApp(w: Win) {
    var addr by remember(w.url) { mutableStateOf(w.url) }
    LaunchedEffect(Cfg.noImg) { w.web?.settings?.blockNetworkImage = Cfg.noImg }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Color(0xFF14142A)).padding(4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Pill("\u25C0") { w.web?.goBack() }
            Pill("\u25B6") { w.web?.goForward() }
            Pill("\u27F3") { w.web?.reload() }
            BasicTextField(
                addr, { addr = it }, singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 13.sp),
                cursorBrush = SolidColor(NEON),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go, keyboardType = KeyboardType.Uri),
                keyboardActions = KeyboardActions(onGo = { w.web?.loadUrl(fixUrl(addr)) }),
                modifier = Modifier.weight(1f).height(36.dp).clip(RoundedCornerShape(18.dp)).background(PANEL).padding(horizontal = 12.dp, vertical = 9.dp)
            )
            Pill("\u279C") { w.web?.loadUrl(fixUrl(addr)) }
        }
        AndroidView(
            factory = { c ->
                val v = w.web ?: makeWeb(c, w).also { w.web = it }
                (v.parent as? ViewGroup)?.removeView(v)   // re-attach safely after minimize
                v
            },
            modifier = Modifier.weight(1f).fillMaxWidth()
        )
    }
}

// ================= Files =================
fun grantFiles(ctx: Context) {
    val pkg = Uri.parse("package:" + ctx.packageName)
    val i = if (Build.VERSION.SDK_INT >= 30) Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, pkg)
    else Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg)
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    ctx.startActivity(i)
}

fun openFile(ctx: Context, f: File) {
    if (f.name.endsWith(".exe", true) || f.name.endsWith(".msi", true)) {
        runExe(ctx, f)
        return
    }
    try {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fp", f)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Is file ko kholne wala app nahi mila.", Toast.LENGTH_LONG).show()
    }
}

@Composable
fun FileRow(f: File, onClick: () -> Unit) {
    val ctx = LocalContext.current
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(if (f.isDirectory) "\uD83D\uDCC1" else "\uD83D\uDCC4", fontSize = 18.sp)
        Spacer(Modifier.width(10.dp))
        Text(f.name, color = Color.White, fontSize = 14.sp, maxLines = 1, modifier = Modifier.weight(1f))
        if (!f.isDirectory) Text(Formatter.formatShortFileSize(ctx, f.length()), color = Color.Gray, fontSize = 11.sp)
    }
}

@Composable
fun FilesApp() {
    val ctx = LocalContext.current
    val root = remember { Environment.getExternalStorageDirectory() }
    var dir by remember { mutableStateOf(root) }
    var tick by remember { mutableIntStateOf(0) }
    val list = remember(dir, tick) { dir.listFiles()?.sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() })) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).background(Color(0xFF14142A)).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Pill("Home") { dir = root }
            Pill("Downloads") { dir = File(root, "Download") }
            Pill("Documents") { dir = File(root, "Documents") }
            Pill("Pictures") { dir = File(root, "Pictures") }
            Pill("\u27F3") { tick++ }
        }
        Text(dir.absolutePath, color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
        if (list == null) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Files dikhane ke liye 'All files access' allow karo, phir \u27F3 dabao.", color = Color.White, fontSize = 14.sp)
                Pill("Allow access") { grantFiles(ctx) }
            }
        } else LazyColumn(Modifier.fillMaxSize()) {
            if (dir != root) item { Row(Modifier.fillMaxWidth().clickable { dir = dir.parentFile ?: root }.padding(10.dp)) { Text("\uD83D\uDCC1  ..", color = Color.White) } }
            items(list) { f -> FileRow(f) { if (f.isDirectory) dir = f else openFile(ctx, f) } }
        }
    }
}

// ================= Notepad (autosaves) =================
@Composable
fun NotesApp() {
    val ctx = LocalContext.current
    val sp = remember { ctx.getSharedPreferences("neonpc", Context.MODE_PRIVATE) }
    var t by remember { mutableStateOf(sp.getString("note", "") ?: "") }
    BasicTextField(
        t, { t = it; sp.edit().putString("note", it).apply() },
        textStyle = TextStyle(color = Color.White, fontSize = 15.sp), cursorBrush = SolidColor(NEON),
        modifier = Modifier.fillMaxSize().padding(12.dp)
    )
}

// ================= Calculator =================
@Composable
fun CalcApp() {
    var disp by remember { mutableStateOf("0") }
    var acc by remember { mutableStateOf<Double?>(null) }
    var op by remember { mutableStateOf<String?>(null) }
    var fresh by remember { mutableStateOf(true) }
    fun fmt(r: Double): String = if (r.isNaN()) "Error" else if (r % 1.0 == 0.0 && abs(r) < 1e15) r.toLong().toString() else r.toString()
    fun press(k: String) {
        when (k) {
            "C" -> { disp = "0"; acc = null; op = null; fresh = true }
            "." -> if (!disp.contains(".")) { disp = if (fresh) "0." else "$disp."; fresh = false }
            "+", "-", "\u00D7", "\u00F7", "=" -> {
                val v = disp.toDoubleOrNull() ?: 0.0
                val a = acc
                val o = op
                if (a != null && o != null && !fresh) {
                    val r = when (o) { "+" -> a + v; "-" -> a - v; "\u00D7" -> a * v; else -> if (v == 0.0) Double.NaN else a / v }
                    acc = if (r.isNaN()) null else r
                    disp = fmt(r)
                } else acc = v
                op = if (k == "=") null else k
                fresh = true
            }
            else -> { disp = if (fresh || disp == "0") k else disp + k; fresh = false }
        }
    }
    val rows = listOf(listOf("7", "8", "9", "\u00F7"), listOf("4", "5", "6", "\u00D7"), listOf("1", "2", "3", "-"), listOf("0", ".", "=", "+"))
    Column(Modifier.fillMaxSize().padding(8.dp)) {
        Text(disp, color = NEON, fontSize = 34.sp, maxLines = 1, modifier = Modifier.fillMaxWidth().padding(8.dp))
        Row(Modifier.fillMaxWidth().weight(1f)) { CalcKey("C", Modifier.weight(1f)) { press("C") } }
        rows.forEach { r ->
            Row(Modifier.fillMaxWidth().weight(1f)) { r.forEach { k -> CalcKey(k, Modifier.weight(1f)) { press(k) } } }
        }
    }
}

@Composable
fun CalcKey(k: String, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.fillMaxHeight().padding(3.dp).clip(RoundedCornerShape(10.dp)).background(Color(0x2200F0FF)).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(k, color = Color.White, fontSize = 20.sp)
    }
}
