package com.neonpc.desktop

import android.app.ActivityManager
import android.content.Context
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.text.format.Formatter
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import kotlinx.coroutines.delay

// ================= Task Manager =================
@Composable
fun TaskMgrApp(wins: List<Win>, onKill: (Win) -> Unit) {
    val ctx = LocalContext.current
    val am = remember { ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager }
    var info by remember { mutableStateOf("") }
    var pct by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            val used = mi.totalMem - mi.availMem
            pct = used.toFloat() / mi.totalMem.toFloat()
            info = "RAM: " + Formatter.formatShortFileSize(ctx, used) + " / " + Formatter.formatShortFileSize(ctx, mi.totalMem)
            delay(2000)
        }
    }
    Column(Modifier.fillMaxSize().padding(10.dp)) {
        Text(info, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)).background(Color(0x33FFFFFF))) {
            Box(Modifier.fillMaxWidth(pct.coerceIn(0f, 1f)).fillMaxHeight().background(NEON))
        }
        Spacer(Modifier.height(12.dp))
        Text("RUNNING WINDOWS", color = NEON, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            items(wins.toList()) { w ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(w.title, color = Color.White, fontSize = 14.sp, maxLines = 1, modifier = Modifier.weight(1f))
                    Text(if (w.minimized) "minimized" else "running", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 8.dp))
                    Pill("End task") { onKill(w) }
                }
            }
        }
    }
}

// ================= Paint (draw with finger / mouse) =================
class PaintStroke(val color: Color, val width: Float) {
    val pts = mutableStateListOf<Offset>()
}

@Composable
fun PaintApp() {
    val strokes = remember { mutableStateListOf<PaintStroke>() }
    var color by remember { mutableStateOf(Color.White) }
    var width by remember { mutableFloatStateOf(6f) }
    val palette = listOf(Color.White, NEON, Color(0xFFFF4D6D), Color(0xFFFFD60A), Color(0xFF30D158), Color(0xFFBF5AF2), Color.Black)
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).background(Color(0xFF14142A)).padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically
        ) {
            palette.forEach { c ->
                Box(
                    Modifier.size(30.dp).clip(CircleShape).background(c)
                        .border(if (c == color) 3.dp else 1.dp, if (c == color) NEON else Color(0x66FFFFFF), CircleShape)
                        .clickable { color = c }
                )
            }
            Pill("Thin") { width = 3f }
            Pill("Medium") { width = 8f }
            Pill("Thick") { width = 20f }
            Pill("Undo") { if (strokes.isNotEmpty()) strokes.removeAt(strokes.size - 1) }
            Pill("Clear") { strokes.clear() }
        }
        Canvas(
            Modifier.weight(1f).fillMaxWidth().background(Color(0xFF1B1B2E))
                .pointerInput(color, width) {
                    detectTapGestures { o -> strokes.add(PaintStroke(color, width).also { it.pts.add(o) }) }
                }
                .pointerInput(color, width) {
                    detectDragGestures(
                        onDragStart = { o -> strokes.add(PaintStroke(color, width).also { it.pts.add(o) }) },
                        onDrag = { change, _ ->
                            change.consume()
                            strokes.lastOrNull()?.pts?.add(change.position)
                        }
                    )
                }
        ) {
            strokes.forEach { s ->
                if (s.pts.size == 1) drawCircle(s.color, s.width / 2f, s.pts[0])
                else if (s.pts.size > 1) {
                    val p = Path()
                    p.moveTo(s.pts[0].x, s.pts[0].y)
                    for (i in 1 until s.pts.size) p.lineTo(s.pts[i].x, s.pts[i].y)
                    drawPath(p, s.color, style = Stroke(width = s.width, cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
            }
        }
    }
}

// ================= Terminal (Android shell) =================
@Composable
fun TerminalApp() {
    val lines = remember { mutableStateListOf("NEON Terminal (Android shell). Try: ls, pwd, cd Download, ping -c 2 google.com", "") }
    var cwd by remember { mutableStateOf(Environment.getExternalStorageDirectory().absolutePath) }
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val handler = remember { Handler(Looper.getMainLooper()) }

    fun run(cmd: String) {
        val c = cmd.trim()
        lines.add("$ $c")
        if (c.isEmpty()) return
        if (c == "clear") { lines.clear(); return }
        if (c == "cd" || c.startsWith("cd ")) {
            val arg = c.removePrefix("cd").trim()
            val t = if (arg.isEmpty()) Environment.getExternalStorageDirectory() else if (arg.startsWith("/")) File(arg) else File(cwd, arg)
            val canon = try { t.canonicalFile } catch (e: Exception) { t }
            if (canon.isDirectory) cwd = canon.absolutePath else lines.add("cd: $arg: no such directory")
            return
        }
        val dir = cwd
        Thread {
            val out = try {
                val p = ProcessBuilder("sh", "-c", c).directory(File(dir)).redirectErrorStream(true).start()
                handler.postDelayed({ p.destroy() }, 20000)   // stop commands that run too long
                val text = p.inputStream.bufferedReader().use { it.readText() }
                p.waitFor()
                text.take(20000)
            } catch (e: Exception) {
                "error: " + e.message
            }
            handler.post { out.trimEnd().lines().forEach { lines.add(it) } }
        }.start()
    }

    LaunchedEffect(lines.size) { if (lines.isNotEmpty()) listState.scrollToItem(lines.size - 1) }

    Column(Modifier.fillMaxSize().background(Color(0xFF05080A)).padding(8.dp)) {
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState) {
            items(lines.toList()) { l ->
                Text(l, color = Color(0xFF9DFFB0), fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(cwd.substringAfterLast('/') + " $", color = NEON, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
            Spacer(Modifier.width(6.dp))
            BasicTextField(
                input, { input = it }, singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 14.sp, fontFamily = FontFamily.Monospace),
                cursorBrush = SolidColor(NEON),
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { run(input); input = "" }),
                modifier = Modifier.weight(1f).padding(vertical = 10.dp)
            )
            Pill("Run") { run(input); input = "" }
        }
    }
}
