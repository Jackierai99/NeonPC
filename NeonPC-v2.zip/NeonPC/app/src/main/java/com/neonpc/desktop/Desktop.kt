package com.neonpc.desktop

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.BatteryManager
import android.provider.Settings
import android.webkit.WebView
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.delay

val NEON = Color(0xFF4CC2FF)      // accent colour (Windows-like light blue)
val PANEL = Color(0xFF1F1F1F)     // window background
const val WINLATOR_RELEASES = "https://github.com/brunodev85/winlator/releases"

/** One desktop window. kind: web | files | notes | calc | tasks | paint | term | exe */
class Win(val id: Int, val kind: String, url: String, x: Float, y: Float, w: Float, h: Float) {
    var url by mutableStateOf(url)
    var x by mutableFloatStateOf(x)
    var y by mutableFloatStateOf(y)
    var w by mutableFloatStateOf(w)
    var h by mutableFloatStateOf(h)
    var title by mutableStateOf(appOf(kind).name)
    var minimized by mutableStateOf(false)
    var maxed by mutableStateOf(false)
    var web: WebView? = null     // kept alive while minimized so pages are not lost
}

class Ic(val app: AppDef, val action: () -> Unit)

fun openUrl(ctx: Context, url: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Link khul nahi paaya", Toast.LENGTH_SHORT).show()
    }
}

/** Opens the Windows compatibility engine (needed to run .exe on Android). */
fun launchWinlator(ctx: Context, fallback: () -> Unit) {
    val pm = ctx.packageManager
    val i = listOf("com.winlator", "com.winlator.cmod").firstNotNullOfOrNull { pm.getLaunchIntentForPackage(it) }
    if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i) }
    else {
        Toast.makeText(ctx, "Windows engine abhi installed nahi hai. Download page khol raha hoon.", Toast.LENGTH_LONG).show()
        fallback()
    }
}

fun runExe(ctx: Context, f: File) {
    Toast.makeText(ctx, "Engine me ye file chuno: " + f.absolutePath, Toast.LENGTH_LONG).show()
    launchWinlator(ctx) { openUrl(ctx, WINLATOR_RELEASES) }
}

/** Applies the "UI size" setting, then draws the desktop. */
@Composable
fun Desktop() {
    val base = LocalDensity.current
    CompositionLocalProvider(LocalDensity provides Density(base.density * Cfg.ui, base.fontScale)) { DesktopInner() }
}

@Composable
fun DesktopInner() {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val wins = remember { mutableStateListOf<Win>() }
    var nextId by remember { mutableIntStateOf(1) }
    var startOpen by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val clock by produceState("") {
        while (true) {
            value = SimpleDateFormat("hh:mm a\ndd-MM-yyyy", Locale.getDefault()).format(Date())
            delay(if (Cfg.low) 30000L else 10000L)
        }
    }
    val battery by produceState(-1) {
        while (true) {
            val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val l = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val s = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            value = if (l >= 0 && s > 0) l * 100 / s else -1
            delay(30000L)
        }
    }
    // save settings whenever one changes
    LaunchedEffect(Unit) {
        snapshotFlow { listOf<Any>(Cfg.low, Cfg.mouse, Cfg.speed, Cfg.cursor, Cfg.ui, Cfg.noImg, Cfg.wall) }.collect { Cfg.save(ctx) }
    }

    BackHandler(Cfg.panel || startOpen || wins.any { !it.minimized }) {
        if (Cfg.panel) Cfg.panel = false
        else if (startOpen) startOpen = false
        else wins.lastOrNull { !it.minimized }?.minimized = true
    }

    BoxWithConstraints(Modifier.fillMaxSize().background(Color.Black)) {
        val dw = with(density) { maxWidth.toPx() }
        val barH = with(density) { 52.dp.toPx() }
        val dh = with(density) { maxHeight.toPx() } - barH

        fun focus(w: Win) { if (wins.lastOrNull() != w) { wins.remove(w); wins.add(w) }; w.minimized = false }
        fun kill(w: Win) { w.web?.destroy(); w.web = null; wins.remove(w) }
        fun open(kind: String, url: String = "") {
            startOpen = false
            query = ""
            if (Cfg.low && wins.size >= 3) {
                Toast.makeText(ctx, "Low mode: max 3 windows. Pehle koi window band karo.", Toast.LENGTH_SHORT).show()
                return
            }
            val n = wins.size % 6
            val ww = min(dw * 0.72f, with(density) { 760.dp.toPx() })
            val hh = dh * 0.78f
            wins.add(Win(nextId++, kind, url.ifEmpty { "https://www.google.com" }, 70f + n * 34f, 56f + n * 30f, ww, hh))
        }
        fun toggleKind(kind: String) {
            val w = wins.lastOrNull { it.kind == kind }
            if (w == null) open(kind)
            else if (w.minimized) focus(w)
            else if (wins.lastOrNull() == w) w.minimized = true
            else focus(w)
        }

        // wallpaper
        Wallpaper()

        // desktop icons (Windows-style, filled column by column)
        val icons = listOf(
            Ic(PC_APP) { open("files") },
            Ic(BIN_APP) { Toast.makeText(ctx, "Recycle Bin khaali hai", Toast.LENGTH_SHORT).show() },
            Ic(appOf("web")) { open("web") },
            Ic(appOf("notes")) { open("notes") },
            Ic(appOf("calc")) { open("calc") },
            Ic(appOf("paint")) { open("paint") },
            Ic(appOf("term")) { open("term") },
            Ic(appOf("tasks")) { open("tasks") },
            Ic(appOf("exe")) { open("exe") },
            Ic(SETTINGS_APP) { Cfg.panel = true }
        )
        val perCol = ((maxHeight - 52.dp - 70.dp) / 84.dp).toInt().coerceAtLeast(1)
        Row(Modifier.padding(start = 10.dp, top = 58.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            icons.chunked(perCol).forEach { col ->
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) { col.forEach { DeskIcon(it.app, it.action) } }
            }
        }

        // windows (last = on top)
        wins.toList().forEach { w ->
            key(w.id) {
                if (!w.minimized) WindowFrame(w, dw, dh, wins, { kill(it) }, { focus(w) }) { kill(w) }
            }
        }

        // start menu (Windows 11 style: centred, search, pinned apps)
        if (startOpen) {
            Box(Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { startOpen = false })
            val sh = RoundedCornerShape(12.dp)
            val menuApps = APPS + SETTINGS_APP
            Column(
                Modifier.align(Alignment.BottomCenter).padding(bottom = 60.dp).width(minOf(400.dp, maxWidth - 16.dp))
                    .heightIn(max = maxHeight - 72.dp).clip(sh).background(Color(0xF2262629)).border(1.dp, Color(0x33FFFFFF), sh).padding(14.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color(0x22FFFFFF)).padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("🔍", fontSize = 14.sp)
                    Spacer(Modifier.width(8.dp))
                    BasicTextField(
                        query, { query = it }, singleLine = true,
                        textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                        cursorBrush = SolidColor(NEON),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { if (query.isNotBlank()) open("web", fixUrl(query)) }),
                        decorationBox = { inner ->
                            if (query.isEmpty()) Text("Type here to search", color = Color(0x99FFFFFF), fontSize = 14.sp)
                            inner()
                        },
                        modifier = Modifier.weight(1f).padding(vertical = 11.dp)
                    )
                }
                Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState())) {
                    val q = query.trim()
                    val list = menuApps.filter { q.isEmpty() || it.name.contains(q, ignoreCase = true) }
                    MenuLabel(if (q.isEmpty()) "Pinned" else "Apps")
                    list.chunked(4).forEach { row ->
                        Row(Modifier.fillMaxWidth()) {
                            row.forEach { a ->
                                StartTile(a, Modifier.weight(1f)) { if (a.kind == "settings") { startOpen = false; Cfg.panel = true } else open(a.kind) }
                            }
                            repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                    if (q.isNotEmpty()) MenuItem("🔎  Search web for \"$q\"") { open("web", fixUrl(q)) }
                    if (q.isEmpty()) {
                        MenuLabel("Web apps")
                        MenuItem("🔎  Google") { open("web", "https://www.google.com") }
                        MenuItem("▶  YouTube") { open("web", "https://www.youtube.com") }
                        MenuItem("🎨  Photopea (photo editor)") { open("web", "https://www.photopea.com") }
                        MenuItem("💻  VS Code (web)") { open("web", "https://vscode.dev") }
                        MenuLabel("System")
                        MenuItem("🔓  Allow file access") { startOpen = false; grantFiles(ctx) }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(32.dp).clip(CircleShape).background(NEON), contentAlignment = Alignment.Center) {
                        Text("N", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                    Text("NEON PC User", color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f).padding(start = 10.dp))
                    Box(
                        Modifier.size(40.dp).clip(RoundedCornerShape(8.dp)).clickable { ctx.activity()?.finish() },
                        contentAlignment = Alignment.Center
                    ) { Text("⏻", color = Color.White, fontSize = 18.sp) }
                }
            }
        }

        // taskbar (Windows 11 style: icons in the centre, tray on the right)
        Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(52.dp).background(Color(0xF01C1C1C))) {
            val pinned = listOf("web", "files", "notes")
            Row(
                Modifier.align(Alignment.Center).widthIn(max = maxWidth - 170.dp).horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                // start button (four squares)
                Box(
                    Modifier.size(44.dp).clip(RoundedCornerShape(8.dp)).background(if (startOpen) Color(0x33FFFFFF) else Color.Transparent)
                        .clickable { startOpen = !startOpen },
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(Modifier.size(20.dp)) {
                        val g = size.width * 0.1f
                        val s = (size.width - g) / 2f
                        for (ix in 0..1) for (iy in 0..1)
                            drawRoundRect(NEON, Offset(ix * (s + g), iy * (s + g)), Size(s, s), CornerRadius(2f, 2f))
                    }
                }
                pinned.forEach { k ->
                    val w = wins.lastOrNull { it.kind == k }
                    TaskIcon(appOf(k), w != null, w != null && !w.minimized && wins.lastOrNull() == w) { startOpen = false; toggleKind(k) }
                }
                wins.filter { it.kind !in pinned }.sortedBy { it.id }.forEach { w ->
                    TaskIcon(appOf(w.kind), true, !w.minimized && wins.lastOrNull() == w) {
                        startOpen = false
                        if (w.minimized) focus(w) else if (wins.lastOrNull() == w) w.minimized = true else focus(w)
                    }
                }
            }
            Row(Modifier.align(Alignment.CenterEnd).fillMaxHeight(), verticalAlignment = Alignment.CenterVertically) {
                // tray: tap = quick settings panel
                Row(
                    Modifier.fillMaxHeight().clickable { startOpen = false; Cfg.panel = true }.padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("📶", fontSize = 14.sp)
                    if (battery >= 0) Text("🔋$battery%", color = Color.White, fontSize = 11.sp)
                    Text(clock, color = Color.White, fontSize = 11.sp, lineHeight = 14.sp, textAlign = TextAlign.End)
                }
                // "show desktop" strip
                Box(Modifier.width(14.dp).fillMaxHeight().background(Color(0x33FFFFFF)).clickable { startOpen = false; wins.forEach { it.minimized = true } })
            }
        }

        // 3 dots (top-left corner): opens the settings panel
        Box(
            Modifier.align(Alignment.TopStart).padding(6.dp).size(44.dp).clip(CircleShape).background(Color(0xCC1C1C1C))
                .border(1.dp, Color(0x66FFFFFF), CircleShape).clickable { Cfg.panel = !Cfg.panel },
            contentAlignment = Alignment.Center
        ) { Text("⋮", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold) }

        // settings panel
        if (Cfg.panel) {
            Box(Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { Cfg.panel = false })
            SettingsPanel(
                Modifier.align(Alignment.TopStart).fillMaxHeight(),
                onTaskMgr = { open("tasks") },
                onShowDesktop = { wins.forEach { it.minimized = true } },
                onClose = { Cfg.panel = false }
            )
        }

        // the mouse arrow is always on top
        CursorOverlay()
    }
}

@Composable
fun WindowFrame(w: Win, dw: Float, dh: Float, all: List<Win>, onKill: (Win) -> Unit, onFocus: () -> Unit, onClose: () -> Unit) {
    val d = LocalDensity.current
    val shape = RoundedCornerShape(8.dp)
    val mod = if (w.maxed) Modifier.offset { IntOffset(0, 0) }.size(with(d) { dw.toDp() }, with(d) { dh.toDp() })
    else Modifier.offset { IntOffset(w.x.roundToInt(), w.y.roundToInt()) }.size(with(d) { w.w.toDp() }, with(d) { w.h.toDp() })
    Column(
        mod.clip(shape).background(PANEL).border(1.dp, Color(0x55FFFFFF), shape)
            .pointerInput(Unit) { awaitEachGesture { awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial); onFocus() } }
    ) {
        // title bar: drag to move, double tap = maximize
        Row(
            Modifier.fillMaxWidth().height(40.dp).background(Color(0xFF2B2B2B))
                .pointerInput(Unit) { detectTapGestures(onDoubleTap = { w.maxed = !w.maxed }) }
                .pointerInput(w.maxed, dw, dh) {
                    detectDragGestures { change, drag ->
                        change.consume()
                        if (!w.maxed) {
                            w.x = (w.x + drag.x).coerceIn(-w.w + 120f, dw - 120f)
                            w.y = (w.y + drag.y).coerceIn(0f, dh - 60f)
                        }
                    }
                },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Spacer(Modifier.width(if (w.maxed) 56.dp else 10.dp))
            AppIcon(appOf(w.kind), 18.dp)
            Text(
                w.title, color = Color.White, maxLines = 1, fontSize = 12.sp,
                modifier = Modifier.weight(1f).padding(start = 8.dp)
            )
            TitleBtn("—", Color.White) { w.minimized = true }
            TitleBtn("□", Color.White) { w.maxed = !w.maxed }
            TitleBtn("✕", Color(0xFFFF6B6B)) { onClose() }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (w.kind) {
                "web" -> BrowserApp(w)
                "files" -> FilesApp()
                "notes" -> NotesApp()
                "tasks" -> TaskMgrApp(all, onKill)
                "paint" -> PaintApp()
                "term" -> TerminalApp()
                "exe" -> ExeApp()
                else -> CalcApp()
            }
            if (!w.maxed) {
                // resize handle (bottom-right corner)
                Box(
                    Modifier.align(Alignment.BottomEnd).size(44.dp).pointerInput(Unit) {
                        detectDragGestures { change, drag ->
                            change.consume()
                            w.w = (w.w + drag.x).coerceAtLeast(300.dp.toPx())
                            w.h = (w.h + drag.y).coerceAtLeast(220.dp.toPx())
                        }
                    },
                    contentAlignment = Alignment.BottomEnd
                ) { Text("◢", color = Color(0xAAFFFFFF), fontSize = 22.sp) }
            }
        }
    }
}

@Composable
fun TitleBtn(t: String, c: Color, onClick: () -> Unit) {
    Box(Modifier.width(46.dp).height(40.dp).clickable(onClick = onClick), contentAlignment = Alignment.Center) { Text(t, color = c, fontSize = 14.sp) }
}

@Composable
fun TaskIcon(app: AppDef, running: Boolean, active: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(RoundedCornerShape(8.dp)).background(if (active) Color(0x33FFFFFF) else Color.Transparent).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        AppIcon(app, 28.dp)
        if (running) Box(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 2.dp).width(if (active) 14.dp else 5.dp).height(3.dp)
                .clip(RoundedCornerShape(2.dp)).background(NEON)
        )
    }
}

@Composable
fun DeskIcon(app: AppDef, onClick: () -> Unit) {
    Column(
        Modifier.width(78.dp).clip(RoundedCornerShape(6.dp)).clickable(onClick = onClick).padding(vertical = 6.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AppIcon(app, 42.dp)
        Spacer(Modifier.height(4.dp))
        Text(
            app.name, maxLines = 2, textAlign = TextAlign.Center,
            style = TextStyle(color = Color.White, fontSize = 11.sp, shadow = Shadow(Color.Black, Offset(1f, 1f), 4f))
        )
    }
}

@Composable
fun StartTile(app: AppDef, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AppIcon(app, 38.dp)
        Spacer(Modifier.height(4.dp))
        Text(app.name, color = Color.White, fontSize = 10.sp, maxLines = 1, textAlign = TextAlign.Center)
    }
}

@Composable
fun MenuItem(t: String, onClick: () -> Unit) {
    Text(t, color = Color.White, fontSize = 14.sp, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 12.dp))
}

@Composable
fun MenuLabel(t: String) {
    Text(t, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 10.dp, top = 12.dp, bottom = 4.dp))
}
