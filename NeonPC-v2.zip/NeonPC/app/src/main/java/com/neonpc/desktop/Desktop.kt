package com.neonpc.desktop

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.provider.Settings
import android.webkit.WebView
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.delay

val NEON = Color(0xFF00F0FF)
val PANEL = Color(0xFF0B0B14)
const val WINLATOR_RELEASES = "https://github.com/brunodev85/winlator/releases"

/** One desktop window. kind: web | files | notes | calc | tasks | paint | term */
class Win(val id: Int, val kind: String, url: String, x: Float, y: Float, w: Float, h: Float) {
    var url by mutableStateOf(url)
    var x by mutableFloatStateOf(x)
    var y by mutableFloatStateOf(y)
    var w by mutableFloatStateOf(w)
    var h by mutableFloatStateOf(h)
    var title by mutableStateOf(
        when (kind) {
            "files" -> "Files"; "notes" -> "Notepad"; "calc" -> "Calculator"
            "tasks" -> "Task Manager"; "paint" -> "Paint"; "term" -> "Terminal"
            else -> "Browser"
        }
    )
    var minimized by mutableStateOf(false)
    var maxed by mutableStateOf(false)
    var web: WebView? = null     // kept alive while minimized so pages are not lost
}

class Ic(val emoji: String, val label: String, val action: () -> Unit)

fun launchWinlator(ctx: Context, fallback: () -> Unit) {
    val pm = ctx.packageManager
    val i = listOf("com.winlator", "com.winlator.cmod").firstNotNullOfOrNull { pm.getLaunchIntentForPackage(it) }
    if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i) }
    else {
        Toast.makeText(ctx, "Winlator installed nahi hai. Download page khol raha hoon.", Toast.LENGTH_LONG).show()
        fallback()
    }
}

/** Applies the "UI size" setting, then draws the desktop. */
@Composable
fun Desktop() {
    val base = LocalDensity.current
    CompositionLocalProvider(LocalDensity provides Density(base.density * Cfg.ui, base.fontScale)) { DesktopInner() }
}

@Composable
fun DesktopInner() {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val wins = remember { mutableStateListOf<Win>() }
    var nextId by remember { mutableIntStateOf(1) }
    var startOpen by remember { mutableStateOf(false) }
    val time by produceState("") {
        while (true) {
            value = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            delay(if (Cfg.low) 30000L else 10000L)
        }
    }
    val battery by produceState(-1) {
        while (true) {
            val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val l = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val s = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            value = if (l >= 0 && s > 0) l * 100 / s else -1
            delay(30000L)
        }
    }
    // save settings whenever one changes
    LaunchedEffect(Unit) {
        snapshotFlow { listOf<Any>(Cfg.low, Cfg.mouse, Cfg.speed, Cfg.cursor, Cfg.ui, Cfg.noImg) }.collect { Cfg.save(ctx) }
    }

    BackHandler(Cfg.panel || startOpen || wins.any { !it.minimized }) {
        if (Cfg.panel) Cfg.panel = false
        else if (startOpen) startOpen = false
        else wins.lastOrNull { !it.minimized }?.minimized = true
    }

    BoxWithConstraints(Modifier.fillMaxSize().background(Color.Black)) {
        val dw = with(density) { maxWidth.toPx() }
        val barH = with(density) { 52.dp.toPx() }
        val dh = with(density) { maxHeight.toPx() } - barH

        fun focus(w: Win) { if (wins.lastOrNull() != w) { wins.remove(w); wins.add(w) }; w.minimized = false }
        fun kill(w: Win) { w.web?.destroy(); w.web = null; wins.remove(w) }
        fun open(kind: String, url: String = "") {
            startOpen = false
            if (Cfg.low && wins.size >= 3) {
                Toast.makeText(ctx, "Low mode: max 3 windows. Pehle koi window band karo.", Toast.LENGTH_SHORT).show()
                return
            }
            val n = wins.size % 6
            val ww = min(dw * 0.72f, with(density) { 760.dp.toPx() })
            val hh = dh * 0.78f
            wins.add(Win(nextId++, kind, url.ifEmpty { "https://www.google.com" }, 70f + n * 34f, 56f + n * 30f, ww, hh))
        }

        // wallpaper (plain colour in low mode = much lighter)
        if (Cfg.low) Box(Modifier.fillMaxSize().background(Color(0xFF07041A)))
        else Canvas(Modifier.fillMaxSize()) {
            drawRect(Brush.linearGradient(listOf(Color(0xFF05010F), Color(0xFF1A0540), Color(0xFF00202A))))
            for (i in 0..24) drawLine(NEON.copy(alpha = 0.06f), Offset(i * size.width / 24f, 0f), Offset(i * size.width / 24f, size.height), 1.5f)
            for (i in 0..14) drawLine(NEON.copy(alpha = 0.06f), Offset(0f, i * size.height / 14f), Offset(size.width, i * size.height / 14f), 1.5f)
        }

        // desktop icons
        val icons = listOf(
            Ic("🌐", "Browser") { open("web") },
            Ic("📁", "Files") { open("files") },
            Ic("📝", "Notepad") { open("notes") },
            Ic("🧮", "Calculator") { open("calc") },
            Ic("🎨", "Paint") { open("paint") },
            Ic("⌨", "Terminal") { open("term") },
            Ic("📊", "Task Mgr") { open("tasks") },
            Ic("⚙", "Settings") { Cfg.panel = true }
        )
        Row(Modifier.padding(start = 14.dp, top = 60.dp, end = 14.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            icons.chunked(3).forEach { col ->
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) { col.forEach { DeskIcon(it.emoji, it.label, it.action) } }
            }
        }

        // windows (last = on top)
        wins.toList().forEach { w ->
            key(w.id) {
                if (!w.minimized) WindowFrame(w, dw, dh, wins, { kill(it) }, { focus(w) }) { kill(w) }
            }
        }

        // start menu
        if (startOpen) {
            Box(Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { startOpen = false })
            val sh = RoundedCornerShape(12.dp)
            Column(
                Modifier.align(Alignment.BottomStart).padding(start = 8.dp, bottom = 60.dp).width(270.dp).heightIn(max = 430.dp)
                    .clip(sh).background(Color(0xF2121224)).border(1.dp, NEON, sh).verticalScroll(rememberScrollState()).padding(8.dp)
            ) {
                MenuItem("🌐  Browser") { open("web") }
                MenuItem("📁  Files") { open("files") }
                MenuItem("📝  Notepad") { open("notes") }
                MenuItem("🧮  Calculator") { open("calc") }
                MenuItem("🎨  Paint") { open("paint") }
                MenuItem("⌨  Terminal") { open("term") }
                MenuItem("📊  Task Manager") { open("tasks") }
                MenuLabel("WEB APPS")
                MenuItem("🔎  Google") { open("web", "https://www.google.com") }
                MenuItem("▶  YouTube") { open("web", "https://www.youtube.com") }
                MenuItem("🎨  Photopea (photo editor)") { open("web", "https://www.photopea.com") }
                MenuItem("💻  VS Code (web)") { open("web", "https://vscode.dev") }
                MenuLabel("WINDOWS .EXE")
                MenuItem("🪟  Winlator") { startOpen = false; launchWinlator(ctx) { open("web", WINLATOR_RELEASES) } }
                MenuLabel("SYSTEM")
                MenuItem("⚙  Settings (mouse / low mode)") { startOpen = false; Cfg.panel = true }
                MenuItem("🔓  Allow file access") { startOpen = false; grantFiles(ctx) }
                MenuItem("⏻  Exit NEON PC") { ctx.activity()?.finish() }
            }
        }

        // taskbar
        Row(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(52.dp).background(Color(0xEE0A0A18)).padding(start = 8.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(Modifier.clip(RoundedCornerShape(8.dp)).background(NEON).clickable { startOpen = !startOpen }.padding(horizontal = 14.dp, vertical = 10.dp)) {
                Text("⊞ START", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                wins.sortedBy { it.id }.forEach { w ->
                    val active = wins.lastOrNull() == w && !w.minimized
                    TaskBtn(w, active) {
                        startOpen = false
                        if (w.minimized) focus(w) else if (active) w.minimized = true else focus(w)
                    }
                }
            }
            if (battery >= 0) Text("🔋$battery%", color = Color.White, fontSize = 12.sp)
            Text(
                "📶", fontSize = 16.sp,
                modifier = Modifier.clip(RoundedCornerShape(6.dp)).clickable { startSys(ctx, Settings.ACTION_WIFI_SETTINGS) }.padding(6.dp)
            )
            Text(time, color = Color.White, fontSize = 12.sp)
            // "show desktop" strip at the far right
            Box(Modifier.width(18.dp).fillMaxHeight().background(Color(0x4400F0FF)).clickable { wins.forEach { it.minimized = true } })
        }

        // 3 dots (top-left corner): opens the settings panel
        Box(
            Modifier.align(Alignment.TopStart).padding(6.dp).size(44.dp).clip(CircleShape).background(Color(0xCC0A0A18))
                .border(1.dp, NEON, CircleShape).clickable { Cfg.panel = !Cfg.panel },
            contentAlignment = Alignment.Center
        ) { Text("⋮", color = NEON, fontSize = 24.sp, fontWeight = FontWeight.Bold) }

        // settings panel
        if (Cfg.panel) {
            Box(Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { Cfg.panel = false })
            SettingsPanel(
                Modifier.align(Alignment.TopStart).fillMaxHeight(),
                onTaskMgr = { open("tasks") },
                onShowDesktop = { wins.forEach { it.minimized = true } },
                onClose = { Cfg.panel = false }
            )
        }

        // the mouse arrow is always on top
        CursorOverlay()
    }
}

@Composable
fun WindowFrame(w: Win, dw: Float, dh: Float, all: List<Win>, onKill: (Win) -> Unit, onFocus: () -> Unit, onClose: () -> Unit) {
    val d = LocalDensity.current
    val shape = RoundedCornerShape(10.dp)
    val mod = if (w.maxed) Modifier.offset { IntOffset(0, 0) }.size(with(d) { dw.toDp() }, with(d) { dh.toDp() })
    else Modifier.offset { IntOffset(w.x.roundToInt(), w.y.roundToInt()) }.size(with(d) { w.w.toDp() }, with(d) { w.h.toDp() })
    Column(
        mod.clip(shape).background(PANEL).border(if (Cfg.low) 1.dp else 1.5.dp, NEON, shape)
            .pointerInput(Unit) { awaitEachGesture { awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial); onFocus() } }
    ) {
        // title bar: drag to move, double tap = maximize
        Row(
            Modifier.fillMaxWidth().height(40.dp)
                .background(if (Cfg.low) Brush.horizontalGradient(listOf(Color(0xFF14102A), Color(0xFF14102A))) else Brush.horizontalGradient(listOf(Color(0xFF1B0A3A), Color(0xFF062A3A))))
                .pointerInput(Unit) { detectTapGestures(onDoubleTap = { w.maxed = !w.maxed }) }
                .pointerInput(w.maxed, dw, dh) {
                    detectDragGestures { change, drag ->
                        change.consume()
                        if (!w.maxed) {
                            w.x = (w.x + drag.x).coerceIn(-w.w + 120f, dw - 120f)
                            w.y = (w.y + drag.y).coerceIn(0f, dh - 60f)
                        }
                    }
                },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                w.title, color = Color.White, maxLines = 1, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f).padding(start = if (w.maxed) 56.dp else 12.dp)
            )
            TitleBtn("—", Color.White) { w.minimized = true }
            TitleBtn("▢", Color.White) { w.maxed = !w.maxed }
            TitleBtn("✕", Color(0xFFFF4D6D)) { onClose() }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (w.kind) {
                "web" -> BrowserApp(w)
                "files" -> FilesApp()
                "notes" -> NotesApp()
                "tasks" -> TaskMgrApp(all, onKill)
                "paint" -> PaintApp()
                "term" -> TerminalApp()
                else -> CalcApp()
            }
            if (!w.maxed) {
                // resize handle (bottom-right corner)
                Box(
                    Modifier.align(Alignment.BottomEnd).size(44.dp).pointerInput(Unit) {
                        detectDragGestures { change, drag ->
                            change.consume()
                            w.w = (w.w + drag.x).coerceAtLeast(300.dp.toPx())
                            w.h = (w.h + drag.y).coerceAtLeast(220.dp.toPx())
                        }
                    },
                    contentAlignment = Alignment.BottomEnd
                ) { Text("◢", color = NEON, fontSize = 22.sp) }
            }
        }
    }
}

@Composable
fun TitleBtn(t: String, c: Color, onClick: () -> Unit) {
    Box(Modifier.size(40.dp).clickable(onClick = onClick), contentAlignment = Alignment.Center) { Text(t, color = c, fontSize = 15.sp) }
}

@Composable
fun TaskBtn(w: Win, active: Boolean, onClick: () -> Unit) {
    val sh = RoundedCornerShape(8.dp)
    Box(
        Modifier.clip(sh).background(if (active) Color(0x5500F0FF) else Color(0x22FFFFFF))
            .border(1.dp, if (active) NEON else Color(0x44FFFFFF), sh).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 10.dp)
    ) { Text(w.title.take(14), color = Color.White, fontSize = 12.sp, maxLines = 1) }
}

@Composable
fun DeskIcon(emoji: String, label: String, onClick: () -> Unit) {
    Column(Modifier.width(76.dp).clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(emoji, fontSize = 32.sp)
        Text(label, color = Color.White, fontSize = 11.sp)
    }
}

@Composable
fun MenuItem(t: String, onClick: () -> Unit) {
    Text(t, color = Color.White, fontSize = 14.sp, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 12.dp))
}

@Composable
fun MenuLabel(t: String) {
    Text(t, color = NEON, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 10.dp, top = 10.dp, bottom = 2.dp))
}
