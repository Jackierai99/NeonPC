# NEON PC
Ek PC jaisa desktop app (Android): windows, taskbar, start menu, browser (Chromium WebView, desktop mode),
file manager, notepad, calculator, paint, terminal, task manager, web apps.
Windows .exe ke liye 'Windows Apps' screen hai (.exe khud ye app nahi chalata, uske liye Windows engine chahiye).

## Top-left corner ka  ⋮  (3 dots)
Settings panel kholta hai:
- Wallpaper (6 built-in + Gallery se photo)
- Touch / Mouse mode switch (mouse arrow)
- Low device mode (kamzor phone ke liye)
- Mouse speed, arrow size, UI size, brightness, volume, Wi-Fi, Bluetooth, Task Manager

## Mouse mode gestures
- 1 ungli drag = arrow move
- 1 tap = click, double-tap + drag = drag/drop
- 2 ungli tap = right-click (long press)
- 2 ungli drag = scroll

Build: GitHub Actions (build.yml) ya Android Studio: gradle assembleDebug
APK: app/build/outputs/apk/debug/app-debug.apk
